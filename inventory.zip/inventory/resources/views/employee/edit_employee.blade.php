@extends('layouts.app')
@section('content')
<div class="content-page">
<div class="content">
<div class="container">
<!-- Page-Title -->
<div class="row">
<div class="col-sm-12">
    <h4 class="pull-left page-title">Welcome !</h4>
    <ol class="breadcrumb pull-right">
        <li><a href="#">Echobvel</a></li>
        <li class="active">IT</li>
    </ol>
</div>
</div>

<!-- Start Widget -->
<div class="row">
<!-- Basic example -->
<div class="col-md-2"></div>
<div class="col-md-8 ">
    <div class="panel panel-default">
        <div class="panel-heading"><h3 class="panel-title">Add Employee</h3></div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class="panel-body">
            <form role="form" action="{{ url('update-employee') }}" method="post" enctype="multipart/form-data">
            	@csrf
                <div class="form-group">
                    <label for="exampleInputEmail1">Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Full Name"required value="{{ $employees->name }}">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword20">Email</label>
                    <input type="email" class="form-control" name="email" placeholder="Email"required value="{{ $employees->email }}">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword21">Phone</label>
                    <input type="text" class="form-control" name="phone" placeholder="phone" value="{{ $employees->phone }}">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword19">Address</label>
                    <input type="text" class="form-control" name="address" placeholder="address" value="{{ $employees->address }}">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword18">Expeience</label>
                    <input type="text" class="form-control" name="experience" placeholder="experience" value="{{ $employees->experience }}">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword17">NID NO.</label>
                    <input type="text" class="form-control" name="nid_no" placeholder="NID NO" value="{{ $employees->nid_no }}">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword41">Salary</label>
                    <input type="text" class="form-control" name="salary" placeholder="salary" value="{{ $employees->salary }}">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword13">Vacation</label>
                    <input type="text" class="form-control" name="vacation" placeholder="vacation" value="{{ $employees->vacation }}">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword12">City</label>
                    <input type="text" class="form-control" name="city" placeholder="city" value="{{ $employees->city }}">
                </div>
                <input type="hidden" name="employee_id" value="{{ $employees->id }}">
                <div class="form-group">
                	<img id="image" src="#" />
                    <label for="exampleInputPassword11">New Photo</label>
                    <input type="file"  name="photo" accept="image/*"   onchange="readURL(this);">
                </div>
                <div class="form-group">
                	<img id="image" src="#" />
                    <label for="exampleInputPassword11">Old Photo</label>
                    <td> <img src="{{ asset('uploads/employee') }}/{{ $employees->photo}}" height="80" width="80" alt="product image not found"> </td>

                </div>

                <button type="submit" class="btn btn-purple waves-effect waves-light">Submit</button>
            </form>
        </div><!-- panel-body -->
    </div> <!-- panel -->
</div> <!-- col-->

</div>
</div> <!-- container -->

</div> <!-- content -->
</div>

<script type="text/javascript">
function readURL(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();
reader.onload = function (e) {
$('#image')
  .attr('src', e.target.result)
  .width(80)
  .height(80);
};
reader.readAsDataURL(input.files[0]);
}
}
</script>
@endsection

@extends('layouts.app')
@section('content')
<div class="content-page">
    <div class="content">
        <div class="container">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Welcome !</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="#">Echobvel</a></li>
                        <li class="active">IT</li>
                    </ol>
                </div>
            </div>

            <!-- Start Widget -->
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">All Customers</h3>
                            <a href="{{ route('add.employee') }}" class="btn btn-sm btn-info pull-right">Add New</a>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <table id="datatable" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Phone</th>
                                                <th>Address</th>
                                                <th>Image</th>
                                                <th>City</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($allSuppliers as $allSupplier)
                                            <tr>
                                                <td>{{ $allSupplier->name}}</td>
                                                <td>{{ $allSupplier->phone}}</td>
                                                <td>{{ $allSupplier->address}}</td>
                                                <td> <img src="{{ asset('uploads/supplier') }}/{{ $allSupplier->photo}}" height="80" width="80" alt="product image not found"> </td>
                                                <td>{{ $allSupplier->city}}</td>
                                                    <td>
                                                      <div class="btn-group" role="group" aria-label="Basic example">
                                                        <a class="btn btn-info" href="{{ url('view-supplier') }}/{{ $allSupplier->id}}">View</a>
                                                        <a class="btn btn-success" href="{{ url('edit-supplier') }}/{{ $allSupplier->id}}">Edit</a>
                                                        <a class="btn btn-danger" href="{{ url('delete-supplier') }}/{{ $allSupplier->id}}">Delete</a>
                                                </div>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- container -->
    </div> <!-- content -->
</div>


@endsection

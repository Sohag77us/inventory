<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class CategoryController extends Controller
{
  public function AddCategory (){
   return view('category/add_category');
  }

        public function InsertCategory(Request $request){
        $category = new Category;
        $category->cat_name=$request->cat_name;
        $category->save();
        return back();
        }
        public function AllCategory(){
        $category= Category::orderBy('id', 'desc')->get();
        return view('category/all_category',compact('category'));
        }
        public function EditCategory($cat_id){
        $category= Category::find($cat_id);
        return view('category/edit_category',compact('category'));
        }
        public function UpdateCategory(Request $request){
        $category= Category::find($request->cat_id);
        $category->cat_name=$request->cat_name;
        $category->save();
        return back();
        }
        public function DeleteCategory($id)
        {
        $category=Category::find($id)->delete();
        if ($category) {
           $notification=array(
           'messege'=>'Delete Successfully Category ',
           'alert-type'=>'success'
            );
          return Redirect()->route('home')->with($notification);
       }else{
        $notification=array(
           'messege'=>'error ',
           'alert-type'=>'success'
            );
           return Redirect()->back()->with($notification);
       }

}


}

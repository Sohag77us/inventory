<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Customer;
use App\Category;
class PosController extends Controller
{
  public function index()
 {
   $product=DB::table('products')
       ->join('categories','products.cat_id','categories.id')
       ->select('categories.cat_name','products.*')
       ->get();

$customer=Customer::all();
$categories=Category::all();
   return view('pos/pos', compact('product','customer','categories'));
 }
}

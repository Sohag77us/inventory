<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Expense;
use DB;
class ExpenseController extends Controller
{
  public function AddExpense(){
   return view('expense/add_expense');
  }
  public function InserExpense(Request $request){
  $expense = new Expense;
  $expense->details=$request->details;
  $expense->amount=$request->amount;
  $expense->month=$request->month;
  $expense->date=$request->date;
  $expense->year=$request->year;
  $expense->save();
  return back();
  }

  public function TodayExpense()
   {
     $date= date("d/m/y");
     $today=DB::table('expenses')->where('date',$date)->get();
     return view('expense/today_expense', compact('today'));
   }

   public function EditTodayExpense($id)
      {
      	$tdy=Expense::find($id);
      	return view('expense/edit_today_expense', compact('tdy'));
      }
      public function UpdateExpense(Request $request){
      $expense= Expense::find($request->expense_id);
      $expense->details=$request->details;
      $expense->amount=$request->amount;
      $expense->save();
      return back();
      }


      public function MonthlyExpense()
        {
            $month= date("F");
            $expense=DB::table('expenses')->where('month',$month)->get();
            return view('expense/monthly_expense', compact('expense'));
        }
        public function YearlyExpense()
 {
      $year=date("Y");
      $year=DB::table('expenses')->where('year',$year)->get();
      return view('expense/yearly_expense', compact('year'));
 }

 public function JanuaryExpense()
  {
      $month="January";
      $expense=DB::table('expenses')->where('month',$month)->get();
      return view('expense/janury_expense', compact('expense'));
  }

  public function FebruaryExpense()
   {
        $month="February";
        $expense=DB::table('expenses')->where('month',$month)->get();
        return view('expense/februry_expense', compact('expense'));
   }

    public function MarchExpense()
   {
        $month="March";
        $expense=DB::table('expenses')->where('month',$month)->get();
        return view('expense/march_expense', compact('expense'));
   }
    public function AprilExpense()
   {
        $month="April";
        $expense=DB::table('expenses')->where('month',$month)->get();
        return view('expense/april_expense', compact('expense'));
   }
    public function MayExpense ()
   {
        $month="May";
        $expense=DB::table('expenses')->where('month',$month)->get();
        return view('expense/april_expense', compact('expense'));
   }
    public function JuneExpense()
   {
        $month="June";
        $expense=DB::table('expenses')->where('month',$month)->get();
        return view('expense/june_expense', compact('expense'));
   }
    public function JulyExpense()
   {
        $month="July";
        $expense=DB::table('expenses')->where('month',$month)->get();
        return view('expense/july_expense', compact('expense'));
   }
    public function AugustExpense()
   {
        $month="August";
        $expense=DB::table('expenses')->where('month',$month)->get();
        return view('expense/aguest_expense', compact('expense'));
   }
    public function SeptemberExpense()
   {
        $month="September";
        $expense=DB::table('expenses')->where('month',$month)->get();
        return view('expense/sept_expense', compact('expense'));
   }
    public function OctoberExpense()
   {
        $month="October";
        $expense=DB::table('expenses')->where('month',$month)->get();
        return view('expense/oct_expense', compact('expense'));
   }
    public function NovemberExpense()
   {
        $month="November";
        $expense=DB::table('expenses')->where('month',$month)->get();
        return view('expense/novembor_expense', compact('expense'));
   }
    public function DecemberExpense()
   {
        $month="December";
        $expense=DB::table('expenses')->where('month',$month)->get();
        return view('expense/december_expense', compact('expense'));
   }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Customer;
use Image;

class CustomerController extends Controller
{
  public function index(){
    return view('customer.add_customer');
  }
  public function store(Request $request) {
  $last_insert_id= DB::table('customers')->insertGetId([
       'name' =>$request->name,
       'email' =>$request->email,
       'phone' =>$request->phone,
       'address' =>$request->address,
       'shopname' =>$request->shopname,
       'account_holder' =>$request->account_holder,
       'account_number' =>$request->account_number,
       'bank_name' =>$request->bank_name,
       'bank_branch' =>$request->bank_branch,
       'city' =>$request->city,
         ]);


      if ($request->hasFile('photo')) {
       $fileName= $last_insert_id.'.'.$request->photo->getClientOriginalExtension();
       Image::make($request->photo)->save(base_path('public/uploads/customer/'.$fileName));
       DB::table('customers')
           ->where('id', $last_insert_id)
           ->update([
             'photo' => $fileName,
           ]);
        }
             return back();
     }

     public function AllCustomer(){
          $customers = Customer::orderBy('id', 'desc')->get();
          return view('customer/all_customer',compact('customers'));
        }

        public function ViewCustomer($id){
                $single = Customer::find($id);
                return view('customer/view_customer',compact('single'));
               }

               public function EditCustomer($id){
                       $custommer = Customer::find($id);
                       return view('customer/edit_customer',compact('custommer'));
                      }
                      public function UpdateCustomer(Request $request) {
                                    $custommer=  Customer::find($request->customer_id);
                                    $custommer->name= $request->name;
                                    $custommer->email= $request->email;
                                    $custommer->phone= $request->phone;
                                    $custommer->address= $request->address;
                                    $custommer->shopname= $request->shopname;
                                    $custommer->account_holder= $request->account_holder;
                                    $custommer->account_number= $request->account_number;
                                    $custommer->bank_name= $request->bank_name;
                                    $custommer->bank_branch= $request->bank_branch;
                                    $custommer->city= $request->city;
                                    $custommer->save();
                                         if ($request->hasFile('photo')) {

                                             $custommer = Customer::find($request->customer_id);
                                             if ($custommer->photo == 'default_image.jpg') {
                                               $fileName= $request->customer_id.'.'.$request->photo->getClientOriginalExtension();
                                               Image::make($request->photo)->save(base_path('public/uploads/customer/'.$fileName));
                                               DB::table('customers')->where('id', $request->customer_id)->update([
                                                     'photo' => $fileName,
                                                   ]);
                                             }else{
                                               unlink(base_path('public/uploads/employee/'.$custommer ->photo));
                                               $fileName= $request->customer_id.'.'.$request->photo->getClientOriginalExtension();
                                               Image::make($request->photo)->save(base_path('public/uploads/customer/'.$fileName));
                                               DB::table('customers')->where('id', $request->customer_id)->update([
                                                     'photo' => $fileName,
                                                   ]);
                                             }
                                           }
                                        return back();
                                   }


                                   public function DeleteCustomer($id) {
                                  $customer=Customer::find($id);
                                   if ($customer->photo == 'default_image.jpg') {
                                       $customer->delete();
                                   }else{
                                     unlink(base_path('public/uploads/customer/'.$customer->photo));
                                    $customer->delete();
                                   }
                                   return back();

                                 }




}

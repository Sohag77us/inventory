<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Exports\ProductsExport;
use App\Imports\ProductsImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Product;
use DB;
use Image;

class ProductController extends Controller
{
  public function AddProduct (){
 return view('product/add_product');
}

public function InsertProduct(Request $request) {
$last_insert_id= DB::table('products')->insertGetId([
    'product_name' =>$request->product_name,
    'cat_id' =>$request->cat_id,
    'sup_id' =>$request->sup_id,
    'product_code' =>$request->product_code,
    'product_store_number' =>$request->product_store_number,
    'product_route' =>$request->product_route,
    'buy_date' =>$request->buy_date,
    'expire_date' =>$request->expire_date,
    'buying_price' =>$request->buying_price,
    'selling_price' =>$request->selling_price,
      ]);

   if ($request->hasFile('photo')) {
    $fileName= $last_insert_id.'.'.$request->photo->getClientOriginalExtension();
    Image::make($request->photo)->save(base_path('public/uploads/product/'.$fileName));
    DB::table('products')
        ->where('id', $last_insert_id)
        ->update([
          'photo' => $fileName,
        ]);
     }

       if ($last_insert_id) {
          $notification=array(
          'messege'=>'Successfully Employee Inserted ',
          'alert-type'=>'success'
           );
         return Redirect()->route('home')->with($notification);
      }else{
       $notification=array(
          'messege'=>'error ',
          'alert-type'=>'success'
           );
          return Redirect()->back()->with($notification);
      }

  }

  public function AllProduct(){
      $allproducts = Product::orderBy('id', 'desc')->get();
      return view('product/all_product',compact('allproducts'));
    }



   public function ViewProduct($id)
  {
      $prod=DB::table('products')
           ->join('categories','products.cat_id','categories.id')
           ->join('suppliers','products.sup_id','suppliers.id')
           ->select('categories.cat_name','products.*','suppliers.name')
           ->where('products.id',$id)
           ->first();
      return view('product/view_product',compact('prod'));
  }


   public function EditProduct($id){
    $prod = Product::find($id);
    return view('product/edit_product',compact('prod'));
   }

   public function UpdateProduct (Request $request) {
         $product=  Product::find($request->product_id);
         $product->product_name= $request->product_name;
         $product->cat_id= $request->cat_id;
         $product->sup_id= $request->sup_id;
         $product->product_code= $request->product_code;
         $product->product_store_number= $request->product_store_number;
         $product->product_route= $request->product_route;
         $product->buy_date= $request->buy_date;
         $product->expire_date= $request->expire_date;
         $product->buying_price= $request->buying_price;
         $product->selling_price= $request->selling_price;
         $product->save();
        if ($request->hasFile('photo')) {

            $product = Employee::find($request->product_id);
            if ($product->photo == 'default_image.jpg') {
              $fileName= $request->product_id.'.'.$request->photo->getClientOriginalExtension();
              Image::make($request->photo)->save(base_path('public/uploads/product/'.$fileName));
              DB::table('products')->where('id', $request->product_id)->update([
                    'photo' => $fileName,
                  ]);
            }else{
              unlink(base_path('public/uploads/product/'.$product ->photo));
              $fileName= $request->product_id.'.'.$request->photo->getClientOriginalExtension();
              Image::make($request->photo)->save(base_path('public/uploads/product/'.$fileName));
              DB::table('products')->where('id', $request->product_id)->update([
                    'photo' => $fileName,
                  ]);
            }
          }
       return back();
    }



   public function DeleteProduct ($id) {
  $product=Product::find($id);
   if ($product->photo == 'default_image.jpg') {
       $product->delete();
   }else{
     unlink(base_path('public/uploads/product/'.$product->photo));
    $product->delete();
   }
   if ($product) {
      $notification=array(
      'messege'=>'Successfully Delete Product ',
      'alert-type'=>'success'
       );
     return back()->with($notification);
  }else{
   $notification=array(
      'messege'=>'error ',
      'alert-type'=>'success'
       );
      return Redirect()->back()->with($notification);
  }

 }


// import product.......................................

public function ImportProduct()
{
  return view('product/import_product');
}
public function export()
{
  return Excel::download(new ProductsExport, 'Products.xlsx');
}



public function import(Request $request)
  {
      $import=Excel::import(new ProductsImport, $request->file('import_file'));
       if ($import) {
              $notification=array(
              'messege'=>'Product Import Successfully',
              'alert-type'=>'success'
               );
             return Redirect()->route('all.product')->with($notification);
          }else{
            return Redirect()->back();
           }

  }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Image;
use App\Company;
class CompanyController extends Controller
{


    public function Setting()
    {

        $setting=DB::table('companies')->first();
        return view('company/setting', compact('setting'));
    }

public function UpdateWebsite(Request $request) {
                    $company=  Company::find($request->company_id);
                    $company->company_name= $request->company_name;
                    $company->company_email= $request->company_email;
                    $company->company_address= $request->company_address;

                    $company->company_phone= $request->company_phone;
                    $company->company_mobile= $request->company_mobile;
                    $company->company_city= $request->company_city;
                    $company->company_country= $request->company_country;
                    $company->company_zipcode= $request->company_zipcode;

                    $company->save();

                   if ($request->hasFile('logo')) {

                       $company = Company::find($request->company_id);
                       if ($company->logo == 'default_image.jpg') {
                         $fileName= $request->company_id.'.'.$request->logo->getClientOriginalExtension();
                         Image::make($request->logo)->save(base_path('public/uploads/logo/'.$fileName));
                         DB::table('companies')->where('id', $request->company_id)->update([
                               'logo' => $fileName,
                             ]);
                       }else{
                         unlink(base_path('public/uploads/logo/'.$company->logo));
                         $fileName= $request->company_id.'.'.$request->logo->getClientOriginalExtension();
                         Image::make($request->logo)->save(base_path('public/uploads/logo/'.$fileName));
                         DB::table('companies')->where('id', $request->company_id)->update([
                               'logo' => $fileName,
                             ]);
                       }
                     }
                  return back();
             }




}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Image;
use DB;
use App\Employee;
class EmployeeController extends Controller
{
    public function index(){
     return view('employee/add_employee');
    }

    public function store(Request $request) {
    $last_insert_id= DB::table('employees')->insertGetId([
        'name' =>$request->name,
        'email' =>$request->email,
        'phone' =>$request->phone,
        'address' =>$request->address,
        'experience' =>$request->experience,
        'nid_no' =>$request->nid_no,
        'salary' =>$request->salary,
        'vacation' =>$request->vacation,
        'city' =>$request->city,
          ]);

       if ($request->hasFile('photo')) {
        $fileName= $last_insert_id.'.'.$request->photo->getClientOriginalExtension();
        Image::make($request->photo)->save(base_path('public/uploads/employee/'.$fileName));
        DB::table('employees')
            ->where('id', $last_insert_id)
            ->update([
              'photo' => $fileName,
            ]);
         }

           if ($last_insert_id) {
              $notification=array(
              'messege'=>'Successfully Employee Inserted ',
              'alert-type'=>'success'
               );
             return Redirect()->route('home')->with($notification);
          }else{
           $notification=array(
              'messege'=>'error ',
              'alert-type'=>'success'
               );
              return Redirect()->back()->with($notification);
          }

      }


     public function AllEmployee(){
         $employees = Employee::orderBy('id', 'desc')->get();
         return view('employee/all_employee',compact('employees'));
       }

       public function ViewEmployee($id){
       $single = Employee::find($id);
       return view('employee/view_employee',compact('single'));
      }
      public function EditEmployee($id){
       $employees = Employee::find($id);
       return view('employee/edit_employee',compact('employees'));
      }

      public function UpdateEmployee(Request $request) {
            $employee=  Employee::find($request->employee_id);
            $employee->name= $request->name;
            $employee->email= $request->email;
            $employee->phone= $request->phone;
            $employee->address= $request->address;
            $employee->experience= $request->experience;
            $employee->nid_no= $request->nid_no;
            $employee->salary= $request->salary;
            $employee->vacation= $request->vacation;
            $employee->city= $request->city;
            $employee->save();
           if ($request->hasFile('photo')) {

               $employee = Employee::find($request->employee_id);
               if ($employee->photo == 'default_image.jpg') {
                 $fileName= $request->employee_id.'.'.$request->photo->getClientOriginalExtension();
                 Image::make($request->photo)->save(base_path('public/uploads/employee/'.$fileName));
                 DB::table('employees')->where('id', $request->employee_id)->update([
                       'photo' => $fileName,
                     ]);
               }else{
                 unlink(base_path('public/uploads/employee/'.$product ->photo));
                 $fileName= $request->employee_id.'.'.$request->photo->getClientOriginalExtension();
                 Image::make($request->photo)->save(base_path('public/uploads/employee/'.$fileName));
                 DB::table('employees')->where('id', $request->employee_id)->update([
                       'photo' => $fileName,
                     ]);
               }
             }
          return back();
       }

   public function DeleteEmployee($id) {
  $employee=Employee::find($id);
   if ($employee->photo == 'default_image.jpg') {
       $employee->delete();
   }else{
     unlink(base_path('public/uploads/employee/'.$employee->photo));
    $employee->delete();
   }
   return back();

 }
}

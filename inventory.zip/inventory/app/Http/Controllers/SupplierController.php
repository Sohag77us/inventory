<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Supplier;
use Image;

class SupplierController extends Controller
{
  public function index(){
 return view('supplier/add_supplier');
}
public function SupplierStore(Request $request) {
 $last_insert_id= DB::table('suppliers')->insertGetId([
      'name' =>$request->name,
      'email' =>$request->email,
      'phone' =>$request->phone,
      'address' =>$request->address,
      'type' =>$request->type,
      'shop' =>$request->shop,
      'accountholder' =>$request->accountholder,
      'accountnumber' =>$request->accountnumber,
      'bankname' =>$request->bankname,
      'branchname' =>$request->branchname,
      'city' =>$request->city,
        ]);

     if ($request->hasFile('photo')) {
      $fileName= $last_insert_id.'.'.$request->photo->getClientOriginalExtension();
      Image::make($request->photo)->save(base_path('public/uploads/supplier/'.$fileName));
      DB::table('suppliers')
          ->where('id', $last_insert_id)
          ->update([
            'photo' => $fileName,
          ]);
       }
            return back();
    }

          public function AllSupplier(){
          $allSuppliers = Supplier::orderBy('id', 'desc')->get();
          return view('supplier/all_supplier',compact('allSuppliers'));
            }

            public function ViewSupplier($id){
                  $supplier = Supplier::find($id);
                  return view('supplier\view_supplier',compact('supplier'));
                 }

                 public function EditSupplier($id){
                      $sup = Supplier::find($id);
                      return view('supplier/edit_supplier',compact('sup'));
                     }

                     public function UpdateSupplier(Request $request) {
                     $supplier=  Supplier::find($request->supplier_id);
                     $supplier->name= $request->name;
                     $supplier->email= $request->email;
                     $supplier->phone= $request->phone;
                     $supplier->address= $request->address;
                     $supplier->type= $request->type;
                     $supplier->shop= $request->shop;
                     $supplier->accountholder= $request->accountholder;
                     $supplier->accountnumber= $request->accountnumber;
                     $supplier->bankname= $request->bankname;
                     $supplier->branchname= $request->branchname;
                     $supplier->city= $request->city;
                     $supplier->save();
                          if ($request->hasFile('photo')) {
                              $supplier = Supplier::find($request->supplier_id);
                              if ($supplier->photo == 'default_image.jpg') {
                                $fileName= $request->supplier_id.'.'.$request->photo->getClientOriginalExtension();
                                Image::make($request->photo)->save(base_path('public/uploads/supplier/'.$fileName));
                                DB::table('suppliers')->where('id', $request->supplier_id)->update([
                                      'photo' => $fileName,
                                    ]);
                              }else{
                                unlink(base_path('public/uploads/supplier/'.$supplier->photo));
                                $fileName= $request->supplier_id.'.'.$request->photo->getClientOriginalExtension();
                                Image::make($request->photo)->save(base_path('public/uploads/supplier/'.$fileName));
                                DB::table('suppliers')->where('id', $request->supplier_id)->update([
                                      'photo' => $fileName,
                                    ]);
                              }
                            }
                         return back();
                      }






                         public function DeleteSupplier($id) {
                           $supplier=Supplier::find($id);
                            if ($supplier->photo == 'default_image.jpg') {
                                $supplier->delete();
                            }else{
                              unlink(base_path('public/uploads/supplier/'.$supplier->photo));
                             $supplier->delete();
                            }
                            return back();

                          }









}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\AdvancedSalary;
use DB;
class AdvancedSalaryController extends Controller
{

  public function AddAdvancedSalary(){
    return view('advancedsalary/advance_salary');
  }

  public function InsertAdvanced(Request $request)
     {
       $month=$request->month;
       $emp_id=$request->emp_id;

       $advanced=DB::table('advanced_salaries')
                 ->where('month',$month)
                 ->where('emp_id',$emp_id)
                 ->first();

       if ($advanced === NULL) {
           $data=array();
         $data['emp_id']=$request->emp_id;
         $data['month']=$request->month;
         $data['advanced_salary']=$request->advanced_salary;
         $data['year']=$request->year;

        $advanced=DB::table('advanced_salaries')->insert($data);
         if ($advanced) {
                  $notification=array(
                  'messege'=>'Successfully Advanced Paid ',
                  'alert-type'=>'success'
                   );
                 return Redirect()->back()->with($notification);
              }else{
               $notification=array(
                  'messege'=>'error ',
                  'alert-type'=>'success'
                   );
                  return Redirect()->back()->with($notification);
              }
           }else{
             $notification=array(
                  'messege'=>'Oopss !! Allready advanced Paid in this month! ',
                  'alert-type'=>'error'
                   );
                  return Redirect()->back()->with($notification);
           }
     }


     public function AllSalary()
{
$salary=DB::table('advanced_salaries')
       ->join('employees','advanced_salaries.emp_id','employees.id')
       ->select('advanced_salaries.*','employees.name','employees.salary','employees.photo')
       ->orderBy('id','DESC')
       ->get();
return view('advancedsalary/all_advance_salary', compact('salary'));
}
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
  protected $fillable = [
      'product_name', 'cat_id', 'sup_id','product_code', 'product_store_number', 'product_route',  'buy_date', 'expire_date', 'buying_price','selling_price', 'photo',
  ];
}

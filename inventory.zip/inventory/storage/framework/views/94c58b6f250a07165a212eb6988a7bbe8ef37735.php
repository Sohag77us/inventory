<?php $__env->startSection('content'); ?>
<div class="content-page">
  <div class="content">
        <div class="container">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Welcome ! <?php echo e(date("Y")); ?></h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="#">Echobvel</a></li>
                        <li class="active">IT</li>
                    </ol>
                </div>
            </div>

           <div>
             <a href="<?php echo e(route('january.expense')); ?>" class="btn btn-sm btn-info">January</a>
             <a href="<?php echo e(route('february.expense')); ?>" class="btn btn-sm btn-danger">February</a>
             <a href="<?php echo e(route('march.expense')); ?>" class="btn btn-sm btn-success">March</a>
             <a href="<?php echo e(route('april.expense')); ?>" class="btn btn-sm btn-primary">April</a>
             <a href="<?php echo e(route('may.expense')); ?>" class="btn btn-sm btn-warning">May</a>
             <a href="<?php echo e(route('june.expense')); ?>" class="btn btn-sm btn-info">June</a>
             <a href="<?php echo e(route('july.expense')); ?>" class="btn btn-sm btn-danger">July</a>
             <a href="<?php echo e(route('august.expense')); ?>" class="btn btn-sm btn-success">August</a>
             <a href="<?php echo e(route('september.expense')); ?>" class="btn btn-sm btn-primary">September</a>
             <a href="<?php echo e(route('october.expense')); ?>" class="btn btn-sm btn-warning">October</a>
             <a href="<?php echo e(route('november.expense')); ?>" class="btn btn-sm btn-success">November</a>
             <a href="<?php echo e(route('december.expense')); ?>" class="btn btn-sm btn-info">December</a>
           </div>
            <!-- Start Widget -->
            <div class="row">
	          <div class="col-md-12">
	              <div class="panel panel-default">
	                  <div class="panel-heading">
	                      <h3 class="panel-title text-danger"> Monthly Expense
	                      </h3>
	                  </div>
	                  <div class="panel-body">
	                      <div class="row">
	                          <div class="col-md-12 col-sm-12 col-xs-12">
	                             <table id="datatable" class="table table-striped table-bordered">
	                                  <thead>
	                                      <tr>
	                                          <th>Details</th>
	                                          <th>Date</th>
	                                          <th>Amount</th>
	                                      </tr>
	                                  </thead>
	                                  <tbody>
	                                  	<?php $__currentLoopData = $expense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                      <tr>
	                                          <td><?php echo e($row->details); ?></td>
	                                          <td><?php echo e($row->date); ?></td>

	                                          <td><?php echo e($row->amount); ?></td>
	                                      </tr>
	                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                                  </tbody>
	                              </table>
             <?php
             $total=DB::Table('expenses')->where('month','November')->sum('amount');
             ?>
                       <h4 align="center">Total Expense November Month: <?php echo e($total); ?> Taka</h4

	                          </div>
	                      </div>
	                  </div>
	              </div>
	          </div>
            </div>
        </div> <!-- container -->
    </div> <!-- content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\inventory\resources\views/expense/novembor_expense.blade.php ENDPATH**/ ?>
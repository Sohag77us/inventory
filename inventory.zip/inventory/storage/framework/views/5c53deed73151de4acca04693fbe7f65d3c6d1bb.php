<?php $__env->startSection('content'); ?>
<div class="content-page">
    <div class="content">
        <div class="container">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Welcome !</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="#">Echobvel</a></li>
                        <li class="active">IT</li>
                    </ol>
                </div>
            </div>

            <!-- Start Widget -->
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">All Customers</h3>
                            <a href="<?php echo e(route('add.employee')); ?>" class="btn btn-sm btn-info pull-right">Add New</a>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <table id="datatable" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Image</th>
                                                <th>Address</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                              <td><?php echo e($row->company_name); ?></td>
                                              <td> <img src="<?php echo e(asset('uploads/logo')); ?>/<?php echo e($row->logo); ?>" height="80" width="80" alt="product image not found"> </td>
                                              <td><?php echo e($row->company_address); ?></td>
                                              <td><?php echo e($row->company_email); ?></td>
                                              <td><?php echo e($row->company_phone); ?></td>
                                              
                                              

                                                    <td>
                                                      <div class="btn-group" role="group" aria-label="Basic example">
                                                        <a class="btn btn-info" href="<?php echo e(url('view-company')); ?>/<?php echo e($row->id); ?>">View</a>
                                                        <a class="btn btn-success" href="<?php echo e(url('edit-company')); ?>/<?php echo e($row->id); ?>">Edit</a>
                                                        <a class="btn btn-danger" href="<?php echo e(url('delete-company')); ?>/<?php echo e($row->id); ?>">Delete</a>
                                                </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- container -->
    </div> <!-- content -->
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\inventory\resources\views/company/all_company_details.blade.php ENDPATH**/ ?>
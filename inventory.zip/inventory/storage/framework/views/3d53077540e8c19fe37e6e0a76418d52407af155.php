<?php $__env->startSection('content'); ?>
<div class="content-page">
  <div class="content">
        <div class="container">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Welcome !</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="#">Echobvel</a></li>
                        <li class="active">IT</li>
                    </ol>
                </div>
            </div>

            <!-- Start Widget -->
            <div class="row">
	           <!-- Basic example -->
	           <div class="col-md-2"></div>
                <div class="col-md-8 ">
                    <div class="panel panel-default">
                        <div class="panel-heading"><h3 class="panel-title">Edit Product</h3></div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="panel-body">
                            <form role="form" action="<?php echo e(url('update-product')); ?>" method="post" enctype="multipart/form-data">
                            	<?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Product Name</label>
                                    <input type="text" class="form-control" name="product_name" value="<?php echo e($prod->product_name); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword20">Produt Code</label>
                                    <input type="text" class="form-control" name="product_code" value="<?php echo e($prod->product_code); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword21">Category</label>
                                    <?php
                                    $cat=DB::table('categories')->get();
                                    ?>
                                    <select name="cat_id" class="form-control">
                                    	<?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($row->id); ?>" <?php if($prod->cat_id==$row->id) { echo "selected";} ?> ><?php echo e($row->cat_name); ?></option>
                                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                 <div class="form-group">
                                    <label for="exampleInputPassword21">Supplier</label>
                                    <?php
                                    $sup=DB::table('suppliers')->get();
                                    ?>
                                    <select name="sup_id" class="form-control">
                                    	<?php $__currentLoopData = $sup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    	 <option value="<?php echo e($row->id); ?>" <?php if($prod->sup_id==$row->id) { echo "selected";} ?> ><?php echo e($row->name); ?></option>
                                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword18">Godaun</label>
                                    <input type="text" class="form-control" name="product_store_number" value="<?php echo e($prod->product_store_number); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword17">Product Route</label>
                                    <input type="text" class="form-control" name="product_route" value="<?php echo e($prod->product_route); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword41">Buying Date</label>
                                    <input type="date" class="form-control" name="buy_date"  required value="<?php echo e($prod->buy_date); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword13">Expire Date </label>
                                    <input type="date" class="form-control" name="expire_date"  required value="<?php echo e($prod->expire_date); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword12">Buying Price</label>
                                    <input type="text" class="form-control" name="buying_price" value="<?php echo e($prod->buying_price); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword12">Selling Price</label>
                                    <input type="text" class="form-control" name="selling_price" value="<?php echo e($prod->selling_price); ?>" required>
                                </div>
                                <div class="form-group">
                                	<img id="image" src="#" />
                                    <label for="exampleInputPassword11">Photo</label>
                                    <input type="file"  name="product_image" accept="image/*"   onchange="readURL(this);">
                                </div>
                                <input type="hidden" name="product_id" value="<?php echo e($prod->id); ?>">
                               <div class="form-group">
                                    <label for="exampleInputPassword12">Old Photo</label>
                                    <td> <img src="<?php echo e(asset('uploads/product')); ?>/<?php echo e($prod->photo); ?>" height="80" width="80" alt="product image not found"> </td>
                                </div>
                                <button type="submit" class="btn btn-purple waves-effect waves-light">Update</button>
                            </form>
                        </div><!-- panel-body -->
                    </div> <!-- panel -->
                </div> <!-- col-->

            </div>
        </div> <!-- container -->

    </div> <!-- content -->
</div>

<script type="text/javascript">
	function readURL(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          reader.onload = function (e) {
              $('#image')
                  .attr('src', e.target.result)
                  .width(80)
                  .height(80);
          };
          reader.readAsDataURL(input.files[0]);
      }
   }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\inventory\resources\views/product/edit_product.blade.php ENDPATH**/ ?>
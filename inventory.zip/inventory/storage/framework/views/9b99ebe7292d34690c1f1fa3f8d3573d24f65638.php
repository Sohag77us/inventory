<?php $__env->startSection('content'); ?>
<div class="content-page">
<div class="content">
<div class="container">
<!-- Page-Title -->
<div class="row">
<div class="col-sm-12">
    <h4 class="pull-left page-title">Welcome !</h4>
    <ol class="breadcrumb pull-right">
        <li><a href="#">Echobvel</a></li>
        <li class="active">IT</li>
    </ol>
</div>
</div>

<!-- Start Widget -->
<div class="row">
<!-- Basic example -->
<div class="col-md-2"></div>
<div class="col-md-8 ">
    <div class="panel panel-default">
        <div class="panel-heading"><h3 class="panel-title">Add Customer</h3></div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="panel-body">
            <form role="form" action="<?php echo e(url('/update-customer')); ?>" method="post" enctype="multipart/form-data">
            	<?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleInputEmail1">Name</label> <span style="color:red;font-weight:bold">***</span>
                    <input type="text" class="form-control" name="name" placeholder="Full Name" value="<?php echo e($custommer->name); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword20">Email</label>
                    <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e($custommer->email); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword21">Phone</label><span style="color:red;font-weight:bold">***</span>
                    <input type="text" class="form-control" name="phone" placeholder="phone" value="<?php echo e($custommer->phone); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword19">Address</label><span style="color:red;font-weight:bold">***</span>
                    <input type="text" class="form-control" name="address" placeholder="address" value="<?php echo e($custommer->address); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword18">Shop Name</label>
                    <input type="text" class="form-control" name="shopname" placeholder="Shop Name" value="<?php echo e($custommer->shopname); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword17">Account Holder</label>
                    <input type="text" class="form-control" name="account_holder" placeholder="Account Holder" value="<?php echo e($custommer->account_holder); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword41">Account Number</label>
                    <input type="text" class="form-control" name="account_number" placeholder="Account Number" value="<?php echo e($custommer->account_number); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword13">Bank Name</label>
                    <input type="text" class="form-control" name="bank_name" placeholder="Bank Name" value="<?php echo e($custommer->bank_name); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword12">Bank Branch</label>
                    <input type="text" class="form-control" name="bank_branch" placeholder="Bank Branch" value="<?php echo e($custommer->bank_branch); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword12">City</label>
                    <input type="text" class="form-control" name="city" placeholder="City" value="<?php echo e($custommer->city); ?>">
                </div>
                <input type="hidden" name="customer_id" value="<?php echo e($custommer->id); ?>">
                <div class="form-group">
                	<img id="image" src="#" />
                    <label for="exampleInputPassword11">Photo</label>
                    <input type="file"  name="photo" accept="image/*"   onchange="readURL(this);">
                </div>

                <button type="submit" class="btn btn-purple waves-effect waves-light">Update</button>
            </form>
        </div><!-- panel-body -->
    </div> <!-- panel -->
</div> <!-- col-->

</div>
</div> <!-- container -->

</div> <!-- content -->
</div>

<script type="text/javascript">
function readURL(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();
reader.onload = function (e) {
$('#image')
  .attr('src', e.target.result)
  .width(80)
  .height(80);
};
reader.readAsDataURL(input.files[0]);
}
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\inventory\resources\views/customer/edit_customer.blade.php ENDPATH**/ ?>
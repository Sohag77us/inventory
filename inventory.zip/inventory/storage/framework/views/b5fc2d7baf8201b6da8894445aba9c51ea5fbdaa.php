<?php $__env->startSection('content'); ?>
<div class="wrapper-page" >
    <div class="panel panel-color panel-primary panel-pages" style="border: 1px solid maroon; border-radius: 10px;">
        <div class="panel-heading bg-img">
            <div class="bg-overlay"></div>
            <h3 class="text-center m-t-10 text-white"><strong>Inventory</strong> </h3>
        </div>
        <div class="panel-body">
        <form class="form-horizontal m-t-20" method="POST" action="<?php echo e(route('login')); ?>">
         <?php echo csrf_field(); ?>
            <div class="form-group ">
                <div class="col-xs-12">
                    <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?> input-lg " id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="Email Address">
                </div>
                 <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <div class="col-xs-12">
                    <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> input-lg" id="password" type="password" name="password" required placeholder="Password">
                </div>
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <div class="form-group ">
                <div class="col-xs-12">
                    <div class="checkbox checkbox-primary">
                        <input id="remember" type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <label for="checkbox-signup">
                            Remember me
                        </label>
                    </div>

                </div>
            </div>
            <div class="form-group text-center m-t-40">
                <div class="col-xs-12">
                    <button class="btn btn-primary btn-lg w-lg waves-effect waves-light" type="submit">Log In</button>
                </div>
            </div>
            <div class="form-group m-t-30">
                <div class="col-sm-7">
                    <a href="<?php echo e(route('password.request')); ?>"><i class="fa fa-lock m-r-5"></i> Forgot your password?</a>
                </div>
            </div>
        </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\inventory\resources\views/auth/login.blade.php ENDPATH**/ ?>
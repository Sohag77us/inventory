<?php $__env->startSection('content'); ?>
<div class="content-page">
  <div class="content">
        <div class="container">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Welcome !</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="#">Echobvel</a></li>
                        <li class="active">IT</li>
                    </ol>
                </div>
            </div>

            <!-- Start Widget -->
            <div class="row">
	           <!-- Basic example -->
	           <div class="col-md-2"></div>
                <div class="col-md-8 ">
                    <div class="panel panel-info">
                        <div class="panel-heading"><h3 class="panel-title text-white">Edit Category</h3>

                        </div>
                        <a href="<?php echo e(route('all.category')); ?>" class="pull-right btn btn-danger btn-sm">All Category</a>
                        <div class="panel-body">
                            <form role="form" action="<?php echo e(url('/update-category')); ?>" method="post">
                            	<?php echo csrf_field(); ?>
                                <div class="form-group">
                                  <div class="form-group">
                                    <label for="exampleInputPassword20">Category Name</label>
                                    <input type="text" class="form-control" name="cat_name" placeholder="Category Name" value="<?php echo e($category->cat_name); ?>">
                                  </div>
                                  <input type="hidden" name="cat_id" value="<?php echo e($category->id); ?>">
                                <button type="submit" class="btn btn-success waves-effect waves-light">Update</button>
                            </form>
                        </div><!-- panel-body -->
                    </div> <!-- panel -->
                </div> <!-- col-->

            </div>
        </div> <!-- container -->

    </div> <!-- content -->
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\inventory\resources\views/category/edit_category.blade.php ENDPATH**/ ?>
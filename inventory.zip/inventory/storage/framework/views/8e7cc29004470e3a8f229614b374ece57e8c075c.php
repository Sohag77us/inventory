<?php $__env->startSection('content'); ?>
<div class="content-page">
  <div class="content">
        <div class="container">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="pull-left page-title">Welcome !</h4>
                    <ol class="breadcrumb pull-right">
                        <li><a href="#">Echobvel</a></li>
                        <li class="active">IT</li>
                    </ol>
                </div>
            </div>

            <!-- Start Widget -->
            <div class="row">
	           <!-- Basic example -->
	           <div class="col-md-2"></div>
                <div class="col-md-8 ">
                    <div class="panel panel-default">
                        <div class="panel-heading"><h3 class="panel-title">View Employee</h3></div>
                        <div class="panel-body">

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Name</label>
                                   <p><?php echo e($single->name); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword20">Email</label>
                                   <p><?php echo e($single->email); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword21">Phone</label>
                                    <p><?php echo e($single->phone); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword19">Address</label>
                                    <p><?php echo e($single->address); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword18">Shop Name</label>
                                   <p><?php echo e($single->shopname); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword17">Acount Holder</label>
                                    <p><?php echo e($single->account_holder); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword41">Account Number</label>
                                    <p><?php echo e($single->account_number); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword13">Bank Name</label>
                                   <p><?php echo e($single->bank_name); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword12">Bank Branch</label>
                                   <p><?php echo e($single->bank_branch); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword12">City</label>
                                   <p><?php echo e($single->city); ?></p>
                                </div>
                                <div class="form-group">
                                  <td> <img src="<?php echo e(asset('uploads/customer')); ?>/<?php echo e($single->photo); ?>" height="80" width="80" alt="product image not found"> </td>

                                    <label for="exampleInputPassword11">Photo</label>

                                </div>
                        </div><!-- panel-body -->
                    </div> <!-- panel -->
                </div> <!-- col-->

            </div>
        </div> <!-- container -->

    </div> <!-- content -->
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\inventory\resources\views/customer/view_customer.blade.php ENDPATH**/ ?>